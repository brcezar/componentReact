import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { TextInput, Button } from 'react-native-paper';
import { LOGIN_NAME } from '../App';
import Title from '../Components/Title';
import MyInput from '../Components/MyInput';
import MyButton from '../Components/MyButton';

const witheTheme = {
  colors: { primary: 'white', text: 'white', placeholder: 'white' },
};

const Register = ({ navigation }) => {
  const [name, setName] = React.useState();

  const goToLogin = () => {
    navigation.navigate('Login');
  };

  const press = (message) => {
    console.log(message);
  }

  return (
    <View style={styles.container}>
      <Title name="Register" />
      <TextInput
        label="Your Name"
        value={name}
        onChangeText={(text) => setName(text)}
        mode="flat"
        style={styles.input}
        theme={witheTheme}
        underlineColor="white"
      />
      <TextInput
        label="Email"
        value={name}
        onChangeText={(text) => setName(text)}
        mode="flat"
        style={styles.input}
        theme={witheTheme}
        underlineColor="white"
      />
      <TextInput
        label="Password"
        value={name}
        onChangeText={(text) => setName(text)}
        mode="flat"
        style={styles.input}
        theme={witheTheme}
        underlineColor="white"
      />
      <MyButton title="Cadastrar" icon="rocket" onPressButton={press} />
      <View style={styles.row}>
        <Text style={styles.textWhite}>Already Have an account? </Text>
        <Text style={styles.textWhite} onPress={goToLogin}>
          Login
        </Text>
      </View>
    </View>
  );
};

export default Register;

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 30,
    height: '100%',
    backgroundColor: '#000000',
    alignItems: 'center',
    paddingTop: 30,
  },
  textWhite: {
    color: 'white',
  },
  row: {
    marginTop: 16,
    flexDirection: 'row',
  },
  input: {
    backgroundColor: '#000000',
    width: '100%',
  },
});
