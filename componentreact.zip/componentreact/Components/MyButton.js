import React from 'react';
import { Button } from 'react-native-paper';
import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  button: {
    width: '100%',
    marginTop: 20,
    borderRadius: 50,
    backgroundColor: '#1DE9B6',
  },
  colorBlack: {
    color: 'black',
  },
});

const MyButton = ({ title, icon, onPressButton }) => {

  const click = () => {
    onPressButton('Vim de dentro do componente filho');
  }

  return (
      <Button
        icon={icon}
        mode="contained"
        style={styles.button}
        labelStyle={styles.colorBlack}
        onPress={click}>
        {title}
      </Button>
  )
};

export default MyButton;