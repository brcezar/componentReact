import React from 'react';
import { Text, StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  title: {
    color: 'green',
    fontSize: 30,
    fontWeight: 700,
  },
});

const Title = ({ name }) => {

  return <Text style={styles.title}>Groovy { name }</Text>;
};

export default Title;

Title.defaultProps = {
  title: 'Groovy',
  subTitle: '2'
}