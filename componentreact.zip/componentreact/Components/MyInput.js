import React from 'react';
import { TextInput } from 'react-native-paper';
import { View, Text, Button } from 'react-native';

const MyInput = ({ labelName }) => {
  return <TextInput label={labelName} />;
};

export default MyInput;
